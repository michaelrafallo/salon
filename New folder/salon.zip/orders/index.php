<?php
// Redirect to booking page for nail salon POS
header('Location: ../booking/');
exit;
?>