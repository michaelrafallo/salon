<?php
header('Location: dashboard/');
exit;
?>

